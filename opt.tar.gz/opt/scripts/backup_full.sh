#!/bin/bash

# Script de backup completo
# Uso: backup_full.sh <origen> <destino>
# Ejemplo: backup_full.sh /var/log /backup_dir

# Función de ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
  echo "Uso: $0 <origen> <destino>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo
  echo "Requisitos:"
  echo "  - El destino debe ser un punto de montaje válido."
  echo "  - Si el origen es /www_dir, también debe estar montado."
  exit 0
fi

# Validar parámetros
if [ $# -ne 2 ]; then
  echo "Error: se requieren dos argumentos (origen y destino)."
  echo "Use -help para más información."
  exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +"%Y%m%d")
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Validar existencia de origen
if [ ! -d "$ORIGEN" ]; then
  echo "Error: el origen $ORIGEN no existe."
  exit 1
fi

# Validar que /www_dir esté montado si se va a backupear
if [[ "$ORIGEN" == "/www_dir" ]] && ! mountpoint -q "$ORIGEN"; then
  echo "Error: el origen /www_dir no está montado."
  exit 1
fi

# Validar que el destino esté montado
if ! mountpoint -q "$DESTINO"; then
  echo "Error: el destino $DESTINO no está montado."
  exit 1
fi

# Ejecutar backup
tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN" --warning=no-file-changed --warning=no-file-removed
if [ $? -eq 0 ]; then
  echo "Backup creado en ${DESTINO}/${ARCHIVO}"
else
  echo "Error al crear el backup."
fi

